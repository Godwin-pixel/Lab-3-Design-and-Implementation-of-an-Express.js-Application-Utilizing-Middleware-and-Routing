const express = require("express");
const cors = require("cors");
const multer = require("multer");
const { parse } = require("csv-parse/sync");
const { randomUUID } = require("crypto");

const app = express();
const PORT = process.env.PORT || 4000;

// ---------- Constants ----------
// The spec lists IT/SAFETY/FACILITIES/OTHER in the data model and
// OPERATIONS/QUALITY in the CSV mapping, so all six are accepted.
const CATEGORIES = ["IT", "SAFETY", "FACILITIES", "OTHER", "OPERATIONS", "QUALITY"];
const SEVERITIES = ["LOW", "MEDIUM", "HIGH"];
const STATUSES = ["OPEN", "INVESTIGATING", "RESOLVED"];
const TRANSITIONS = { OPEN: "INVESTIGATING", INVESTIGATING: "RESOLVED" };

// ---------- In-memory store ----------
const incidents = [];

// ---------- Helpers ----------
function validateIncidentInput(body) {
  const errors = [];
  const data = body && typeof body === "object" ? body : {};
  const title = typeof data.title === "string" ? data.title.trim() : "";
  const description = typeof data.description === "string" ? data.description.trim() : "";
  const category = typeof data.category === "string" ? data.category.trim().toUpperCase() : "";
  const severity = typeof data.severity === "string" ? data.severity.trim().toUpperCase() : "";

  if (title.length < 5) errors.push("title is required (minimum 5 characters)");
  if (description.length < 10) errors.push("description is required (minimum 10 characters)");
  if (!CATEGORIES.includes(category)) errors.push(`category must be one of: ${CATEGORIES.join(", ")}`);
  if (!SEVERITIES.includes(severity)) errors.push(`severity must be one of: ${SEVERITIES.join(", ")}`);

  return { errors, value: { title, description, category, severity } };
}

function createIncident({ title, description, category, severity }) {
  const incident = {
    id: randomUUID(),
    title,
    description,
    category,
    severity,
    status: "OPEN",
    reportedAt: new Date().toISOString(),
  };
  incidents.push(incident);
  return incident;
}

// ---------- Middleware ----------
app.use(cors());
app.use(express.json());

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    // MIME types for CSV vary by browser/OS, so the extension is the check.
    if (/\.csv$/i.test(file.originalname || "")) return cb(null, true);
    const err = new Error("Only CSV files are accepted");
    err.status = 400;
    cb(err);
  },
});

// ---------- Routes ----------
app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.get("/api/incidents", (req, res) => {
  res.json(incidents);
});

// Registered before "/:id" so "bulk-upload" is never treated as an id.
app.post("/api/incidents/bulk-upload", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded. Send a CSV in the "file" form field.' });
  }

  let records;
  try {
    records = parse(req.file.buffer, {
      columns: (header) => header.map((h) => h.trim()),
      skip_empty_lines: true,
      trim: true,
      bom: true,
      relax_column_count: true,
    });
  } catch (err) {
    return res.status(400).json({ error: `Could not parse CSV: ${err.message}` });
  }

  let created = 0;
  let skipped = 0;
  for (const row of records) {
    const { errors, value } = validateIncidentInput(row);
    if (errors.length > 0) {
      skipped += 1;
    } else {
      createIncident(value);
      created += 1;
    }
  }

  res.json({ totalRows: records.length, created, skipped });
});

app.post("/api/incidents", (req, res) => {
  const { errors, value } = validateIncidentInput(req.body);
  if (errors.length > 0) {
    return res.status(400).json({ error: "Validation failed", details: errors });
  }
  res.status(201).json(createIncident(value));
});

app.get("/api/incidents/:id", (req, res) => {
  const incident = incidents.find((i) => i.id === req.params.id);
  if (!incident) return res.status(404).json({ error: "Incident not found" });
  res.json(incident);
});

app.patch("/api/incidents/:id/status", (req, res) => {
  const incident = incidents.find((i) => i.id === req.params.id);
  if (!incident) return res.status(404).json({ error: "Incident not found" });

  const next = req.body && req.body.status;
  if (!STATUSES.includes(next)) {
    return res.status(400).json({ error: `status must be one of: ${STATUSES.join(", ")}` });
  }
  if (TRANSITIONS[incident.status] !== next) {
    return res.status(400).json({
      error: `Invalid transition: ${incident.status} -> ${next}`,
    });
  }

  incident.status = next;
  res.json(incident);
});

// ---------- Error handling ----------
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: `Upload error: ${err.message}` });
  }
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "Invalid JSON body" });
  }
  const status = err.status || 500;
  res.status(status).json({ error: status === 500 ? "Internal server error" : err.message });
});

app.listen(PORT, () => {
  console.log(`IncidentTracker API listening on http://localhost:${PORT}`);
});
