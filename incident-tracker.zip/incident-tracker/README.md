# IncidentTracker

A simple incident reporting and tracking app.

- **Backend:** Express.js REST API with an in-memory store (`backend/`)
- **Frontend:** Next.js (React) web UI (`frontend/`)

Data is held in memory only, so it resets whenever the backend restarts.

## Setup

Requires Node.js 18 or newer. Run the backend and frontend in two terminals.

### 1. Backend (port 4000)

```bash
cd backend
npm install
npm start
```

Set a different port with `PORT=5000 npm start`.

### 2. Frontend (port 3000)

```bash
cd frontend
npm install
npm run dev
```

The backend URL is configured in `frontend/.env.local`:

```
NEXT_PUBLIC_API_URL=http://localhost:4000
```

If you change the backend port, update this value and restart the frontend.

Open http://localhost:3000.

## Frontend pages

| Path                | Purpose                                         |
| ------------------- | ----------------------------------------------- |
| `/incidents`        | List all incidents, each linking to its details |
| `/incidents/create` | Create an incident (client-side validation)     |
| `/incidents/[id]`   | View an incident and update its status          |
| `/bulk-upload`      | Upload a CSV and view the result summary        |

## API endpoints

| Method | Path                           | Description                                   |
| ------ | ------------------------------ | --------------------------------------------- |
| GET    | `/health`                      | Returns `{ "status": "ok" }`                  |
| GET    | `/api/incidents`               | List all incidents                            |
| GET    | `/api/incidents/:id`           | Get one incident (404 if not found)           |
| POST   | `/api/incidents`               | Create an incident (400 if validation fails)  |
| PATCH  | `/api/incidents/:id/status`    | Update status (400 invalid transition, 404)   |
| POST   | `/api/incidents/bulk-upload`   | Upload CSV (multipart field name: `file`)     |

### Incident fields

| Field         | Rules                                                                 |
| ------------- | --------------------------------------------------------------------- |
| `id`          | Generated (UUID)                                                      |
| `title`       | Required, min 5 characters                                            |
| `description` | Required, min 10 characters                                           |
| `category`    | `IT`, `SAFETY`, `FACILITIES`, `OTHER`, `OPERATIONS`, `QUALITY`        |
| `severity`    | `LOW`, `MEDIUM`, `HIGH`                                               |
| `status`      | `OPEN` (default), `INVESTIGATING`, `RESOLVED`                         |
| `reportedAt`  | ISO timestamp, set on creation                                        |

Allowed status transitions: `OPEN → INVESTIGATING` and `INVESTIGATING → RESOLVED`.

Errors are returned as JSON, for example `{ "error": "Incident not found" }`.

### Example requests

```bash
curl -X POST http://localhost:4000/api/incidents \
  -H "Content-Type: application/json" \
  -d '{"title":"Network outage","description":"Main office network is down","category":"IT","severity":"HIGH"}'

curl -X PATCH http://localhost:4000/api/incidents/<id>/status \
  -H "Content-Type: application/json" \
  -d '{"status":"INVESTIGATING"}'

curl -F "file=@sample-incidents.csv" http://localhost:4000/api/incidents/bulk-upload
```

## Sample CSV format

Headers must be exactly `title,description,category,severity`:

```csv
title,description,category,severity
Network outage,Main office network is down since 9am,IT,HIGH
Wet floor near entrance,Liquid spill in the main entrance area,SAFETY,MEDIUM
Bad,Too short,IT,HIGH
```

Each row is validated with the same rules as `POST /api/incidents`. Invalid rows are skipped.
The response looks like:

```json
{ "totalRows": 3, "created": 2, "skipped": 1 }
```

A ready-to-use file is included: `sample-incidents.csv` (8 rows: 6 valid, 2 invalid).

## Notes

- The spec's data model lists categories `IT, SAFETY, FACILITIES, OTHER`, while its CSV mapping
  table lists `OPERATIONS` and `QUALITY`. All six values are accepted.
- The optional CSV columns in the mapping table (`status`, `reportedBy`, `location`, `acquiredAt`)
  are not part of the data model, so they are ignored if present.

## Screenshots

Add your screenshots here before submitting:

1. Incident list
2. Create incident form
3. Incident status update
4. CSV upload result
