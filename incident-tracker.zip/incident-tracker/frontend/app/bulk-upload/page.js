"use client";

import { useState } from "react";
import { apiFetch } from "../../lib/api";

export default function BulkUploadPage() {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);

  function onFileChange(e) {
    setResult(null);
    setError("");
    const chosen = e.target.files && e.target.files[0];
    if (chosen && !/\.csv$/i.test(chosen.name)) {
      setFile(null);
      setError("Please select a .csv file.");
      return;
    }
    setFile(chosen || null);
  }

  async function onUpload(e) {
    e.preventDefault();
    if (!file) {
      setError("Please select a CSV file first.");
      return;
    }
    setError("");
    setResult(null);
    setUploading(true);
    try {
      const body = new FormData();
      body.append("file", file);
      setResult(await apiFetch("/api/incidents/bulk-upload", { method: "POST", body }));
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  }

  return (
    <div>
      <h1>Bulk Upload</h1>
      <p>Upload a CSV with the headers <code>title,description,category,severity</code>.</p>
      {error && <div className="error">{error}</div>}
      <form onSubmit={onUpload}>
        <input type="file" accept=".csv,text/csv" onChange={onFileChange} />
        <button type="submit" disabled={uploading || !file}>
          {uploading ? "Uploading..." : "Upload"}
        </button>
      </form>
      {result && (
        <div className="success">
          <strong>Upload complete</strong>
          <ul>
            <li>Total rows: {result.totalRows}</li>
            <li>Created: {result.created}</li>
            <li>Skipped: {result.skipped}</li>
          </ul>
        </div>
      )}
    </div>
  );
}
