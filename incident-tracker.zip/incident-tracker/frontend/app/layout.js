import Link from "next/link";
import "./globals.css";

export const metadata = {
  title: "IncidentTracker",
  description: "Simple incident reporting and tracking",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <header className="nav">
          <strong>IncidentTracker</strong>
          <nav>
            <Link href="/incidents">Incidents</Link>
            <Link href="/incidents/create">New incident</Link>
            <Link href="/bulk-upload">Bulk upload</Link>
          </nav>
        </header>
        <main className="container">{children}</main>
      </body>
    </html>
  );
}
