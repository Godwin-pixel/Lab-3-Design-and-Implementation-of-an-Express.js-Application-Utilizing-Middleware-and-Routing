"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiFetch } from "../../lib/api";

export default function IncidentListPage() {
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    apiFetch("/api/incidents")
      .then(setIncidents)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1>Incidents</h1>
      {error && <div className="error">{error}</div>}
      {loading ? (
        <p>Loading...</p>
      ) : incidents.length === 0 && !error ? (
        <p>
          No incidents yet. <Link href="/incidents/create">Create one</Link> or{" "}
          <Link href="/bulk-upload">upload a CSV</Link>.
        </p>
      ) : (
        incidents.length > 0 && (
          <table>
            <thead>
              <tr>
                <th>Title</th>
                <th>Category</th>
                <th>Severity</th>
                <th>Status</th>
                <th>Reported</th>
              </tr>
            </thead>
            <tbody>
              {incidents.map((i) => (
                <tr key={i.id}>
                  <td>
                    <Link href={`/incidents/${i.id}`}>{i.title}</Link>
                  </td>
                  <td>{i.category}</td>
                  <td>{i.severity}</td>
                  <td>{i.status}</td>
                  <td>{new Date(i.reportedAt).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )
      )}
    </div>
  );
}
