"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { apiFetch, CATEGORIES, SEVERITIES } from "../../../lib/api";

function validate(form) {
  const errors = {};
  if (form.title.trim().length < 5) errors.title = "Title is required (minimum 5 characters).";
  if (form.description.trim().length < 10) errors.description = "Description is required (minimum 10 characters).";
  if (!CATEGORIES.includes(form.category)) errors.category = "Please choose a category.";
  if (!SEVERITIES.includes(form.severity)) errors.severity = "Please choose a severity.";
  return errors;
}

export default function CreateIncidentPage() {
  const router = useRouter();
  const [form, setForm] = useState({ title: "", description: "", category: "", severity: "" });
  const [fieldErrors, setFieldErrors] = useState({});
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    const errors = validate(form);
    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setSubmitting(true);
    try {
      await apiFetch("/api/incidents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      router.push("/incidents");
    } catch (err) {
      setError(err.message);
      setSubmitting(false);
    }
  }

  return (
    <div>
      <h1>Create Incident</h1>
      {error && <div className="error">{error}</div>}
      <form onSubmit={onSubmit} noValidate>
        <label>
          Title
          <input name="title" value={form.title} onChange={update} />
          {fieldErrors.title && <span className="field-error">{fieldErrors.title}</span>}
        </label>
        <label>
          Description
          <textarea name="description" rows={4} value={form.description} onChange={update} />
          {fieldErrors.description && <span className="field-error">{fieldErrors.description}</span>}
        </label>
        <label>
          Category
          <select name="category" value={form.category} onChange={update}>
            <option value="">Select...</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          {fieldErrors.category && <span className="field-error">{fieldErrors.category}</span>}
        </label>
        <label>
          Severity
          <select name="severity" value={form.severity} onChange={update}>
            <option value="">Select...</option>
            {SEVERITIES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          {fieldErrors.severity && <span className="field-error">{fieldErrors.severity}</span>}
        </label>
        <button type="submit" disabled={submitting}>
          {submitting ? "Submitting..." : "Submit"}
        </button>
      </form>
    </div>
  );
}
