"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { apiFetch } from "../../../lib/api";

const STATUSES = ["OPEN", "INVESTIGATING", "RESOLVED"];

export default function IncidentDetailsPage() {
  const { id } = useParams();
  const [incident, setIncident] = useState(null);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    apiFetch(`/api/incidents/${encodeURIComponent(id)}`)
      .then((data) => {
        setIncident(data);
        setStatus(data.status);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  async function updateStatus() {
    setError("");
    setMessage("");
    setSaving(true);
    try {
      const updated = await apiFetch(`/api/incidents/${encodeURIComponent(id)}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      setIncident(updated);
      setStatus(updated.status);
      setMessage(`Status updated to ${updated.status}.`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <p><Link href="/incidents">&larr; Back to incidents</Link></p>
      <h1>Incident Details</h1>
      {loading && <p>Loading...</p>}
      {error && <div className="error">{error}</div>}
      {message && <div className="success">{message}</div>}
      {incident && (
        <div className="card">
          <dl>
            <dt>ID</dt><dd>{incident.id}</dd>
            <dt>Title</dt><dd>{incident.title}</dd>
            <dt>Description</dt><dd>{incident.description}</dd>
            <dt>Category</dt><dd>{incident.category}</dd>
            <dt>Severity</dt><dd>{incident.severity}</dd>
            <dt>Status</dt><dd>{incident.status}</dd>
            <dt>Reported at</dt><dd>{new Date(incident.reportedAt).toLocaleString()}</dd>
          </dl>
          <div className="row">
            <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
              {STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <button onClick={updateStatus} disabled={saving || status === incident.status}>
              {saving ? "Updating..." : "Update status"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
